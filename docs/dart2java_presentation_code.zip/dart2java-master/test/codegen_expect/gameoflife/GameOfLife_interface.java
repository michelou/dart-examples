package gameoflife;

public interface GameOfLife_interface extends gameoflife.BenchmarkBase_interface
{
  void run();

}

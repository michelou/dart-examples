package is_interfaces_test;

public interface Expect_interface extends dart._runtime.base.DartObject_interface
{
  int getX();
  int setX(int value);

}

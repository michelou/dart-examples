package is_interfaces_test;

public interface C_interface extends dart._runtime.base.DartObject_interface, is_interfaces_test.B_interface
{


}

package is_interfaces_test;

public interface B_interface extends is_interfaces_test.A_interface
{


}

package is_interfaces_test;

public interface A_interface extends dart._runtime.base.DartObject_interface
{


}

package org.dartlang.file_import_test.level_1.level_2.at_level_2;

public class __TopLevel
{
  
  
  
  
    public static void atLevel2()
    {
      final dart._runtime.types.simple.TypeEnvironment dart2java$localTypeEnv = dart._runtime.types.simple.TypeEnvironment.ROOT;
      dart.core.__TopLevel.print("At level 2");
    }
}

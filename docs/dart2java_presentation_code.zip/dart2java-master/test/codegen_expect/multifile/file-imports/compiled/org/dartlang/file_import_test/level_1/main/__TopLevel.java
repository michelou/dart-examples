package org.dartlang.file_import_test.level_1.main;

public class __TopLevel
{
  
  
  
  
    public static void main(String[] args)
    {
      final dart._runtime.types.simple.TypeEnvironment dart2java$localTypeEnv = dart._runtime.types.simple.TypeEnvironment.ROOT;
      org.dartlang.file_import_test.level_1.at_level_1.__TopLevel.atLevel1();
      org.dartlang.file_import_test.level_1.level_2.at_level_2.__TopLevel.atLevel2();
      org.dartlang.file_import_test.at_level_0.__TopLevel.atLevel0();
      org.dartlang.file_import_test.other_1.at_other_1.__TopLevel.atOther1();
    }
}

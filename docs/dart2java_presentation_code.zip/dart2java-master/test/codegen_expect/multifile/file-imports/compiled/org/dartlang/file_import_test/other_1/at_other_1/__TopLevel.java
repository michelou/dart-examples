package org.dartlang.file_import_test.other_1.at_other_1;

public class __TopLevel
{
  
  
  
  
    public static void atOther1()
    {
      final dart._runtime.types.simple.TypeEnvironment dart2java$localTypeEnv = dart._runtime.types.simple.TypeEnvironment.ROOT;
      dart.core.__TopLevel.print("At other 1");
    }
}

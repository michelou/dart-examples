package org.dartlang.file_import_test.at_level_0;

public class __TopLevel
{
  
  
  
  
    public static void atLevel0()
    {
      final dart._runtime.types.simple.TypeEnvironment dart2java$localTypeEnv = dart._runtime.types.simple.TypeEnvironment.ROOT;
      dart.core.__TopLevel.print("At level 0");
    }
}

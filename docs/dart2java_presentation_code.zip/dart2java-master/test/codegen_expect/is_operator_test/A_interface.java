package is_operator_test;

public interface A_interface extends dart._runtime.base.DartObject_interface, is_operator_test.AI_interface
{


}

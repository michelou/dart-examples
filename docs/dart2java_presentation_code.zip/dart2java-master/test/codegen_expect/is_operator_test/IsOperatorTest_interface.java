package is_operator_test;

public interface IsOperatorTest_interface extends dart._runtime.base.DartObject_interface
{


}

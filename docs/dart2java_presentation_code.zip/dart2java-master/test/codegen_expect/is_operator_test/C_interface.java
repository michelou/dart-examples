package is_operator_test;

public interface C_interface extends is_operator_test.A_interface
{


}

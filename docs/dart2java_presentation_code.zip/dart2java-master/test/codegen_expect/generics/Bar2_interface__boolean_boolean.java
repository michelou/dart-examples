package generics;

public interface Bar2_interface__boolean_boolean extends dart._runtime.base.DartObject_interface, generics.Bar2_interface<java.lang.Boolean, java.lang.Boolean>, generics.Bar2_interface__boolean_generic<java.lang.Boolean>, generics.Bar2_interface__generic_boolean<java.lang.Boolean>
{
  boolean bar_Bar2__boolean_boolean(boolean a, boolean b);
  boolean getVarA_Bar2__boolean_boolean();
  boolean getVarB_Bar2__boolean_boolean();
  boolean setVarA_Bar2__boolean_boolean(boolean value);
  boolean setVarB_Bar2__boolean_boolean(boolean value);
  default public java.lang.Boolean getVarA_Bar2()
  {
    return this.getVarA_Bar2__boolean_boolean();
  }
  default public java.lang.Boolean getVarB_Bar2()
  {
    return this.getVarB_Bar2__boolean_boolean();
  }
  default public java.lang.Boolean setVarA_Bar2(java.lang.Boolean value)
  {
    return this.setVarA_Bar2__boolean_boolean(((boolean) value));
  }
  default public java.lang.Boolean setVarB_Bar2(java.lang.Boolean value)
  {
    return this.setVarB_Bar2__boolean_boolean(((boolean) value));
  }
  default public java.lang.Boolean bar_Bar2(java.lang.Boolean a, java.lang.Boolean b)
  {
    return this.bar_Bar2__boolean_boolean(((boolean) a), ((boolean) b));
  }
  default public boolean getVarA_Bar2__boolean_generic()
  {
    return this.getVarA_Bar2__boolean_boolean();
  }
  default public java.lang.Boolean getVarB_Bar2__boolean_generic()
  {
    return this.getVarB_Bar2__boolean_boolean();
  }
  default public boolean setVarA_Bar2__boolean_generic(boolean value)
  {
    return this.setVarA_Bar2__boolean_boolean(((boolean) value));
  }
  default public java.lang.Boolean setVarB_Bar2__boolean_generic(java.lang.Boolean value)
  {
    return this.setVarB_Bar2__boolean_boolean(((boolean) value));
  }
  default public boolean bar_Bar2__boolean_generic(boolean a, java.lang.Boolean b)
  {
    return this.bar_Bar2__boolean_boolean(((boolean) a), ((boolean) b));
  }
  default public java.lang.Boolean getVarA_Bar2__generic_boolean()
  {
    return this.getVarA_Bar2__boolean_boolean();
  }
  default public boolean getVarB_Bar2__generic_boolean()
  {
    return this.getVarB_Bar2__boolean_boolean();
  }
  default public java.lang.Boolean setVarA_Bar2__generic_boolean(java.lang.Boolean value)
  {
    return this.setVarA_Bar2__boolean_boolean(((boolean) value));
  }
  default public boolean setVarB_Bar2__generic_boolean(boolean value)
  {
    return this.setVarB_Bar2__boolean_boolean(((boolean) value));
  }
  default public java.lang.Boolean bar_Bar2__generic_boolean(java.lang.Boolean a, boolean b)
  {
    return this.bar_Bar2__boolean_boolean(((boolean) a), ((boolean) b));
  }
}

package generics;

public interface Bar2_interface__int_int extends dart._runtime.base.DartObject_interface, generics.Bar2_interface<java.lang.Integer, java.lang.Integer>, generics.Bar2_interface__int_generic<java.lang.Integer>, generics.Bar2_interface__generic_int<java.lang.Integer>
{
  int bar_Bar2__int_int(int a, int b);
  int getVarA_Bar2__int_int();
  int getVarB_Bar2__int_int();
  int setVarA_Bar2__int_int(int value);
  int setVarB_Bar2__int_int(int value);
  default public java.lang.Integer getVarA_Bar2()
  {
    return this.getVarA_Bar2__int_int();
  }
  default public java.lang.Integer getVarB_Bar2()
  {
    return this.getVarB_Bar2__int_int();
  }
  default public java.lang.Integer setVarA_Bar2(java.lang.Integer value)
  {
    return this.setVarA_Bar2__int_int(((int) value));
  }
  default public java.lang.Integer setVarB_Bar2(java.lang.Integer value)
  {
    return this.setVarB_Bar2__int_int(((int) value));
  }
  default public java.lang.Integer bar_Bar2(java.lang.Integer a, java.lang.Integer b)
  {
    return this.bar_Bar2__int_int(((int) a), ((int) b));
  }
  default public int getVarA_Bar2__int_generic()
  {
    return this.getVarA_Bar2__int_int();
  }
  default public java.lang.Integer getVarB_Bar2__int_generic()
  {
    return this.getVarB_Bar2__int_int();
  }
  default public int setVarA_Bar2__int_generic(int value)
  {
    return this.setVarA_Bar2__int_int(((int) value));
  }
  default public java.lang.Integer setVarB_Bar2__int_generic(java.lang.Integer value)
  {
    return this.setVarB_Bar2__int_int(((int) value));
  }
  default public int bar_Bar2__int_generic(int a, java.lang.Integer b)
  {
    return this.bar_Bar2__int_int(((int) a), ((int) b));
  }
  default public java.lang.Integer getVarA_Bar2__generic_int()
  {
    return this.getVarA_Bar2__int_int();
  }
  default public int getVarB_Bar2__generic_int()
  {
    return this.getVarB_Bar2__int_int();
  }
  default public java.lang.Integer setVarA_Bar2__generic_int(java.lang.Integer value)
  {
    return this.setVarA_Bar2__int_int(((int) value));
  }
  default public int setVarB_Bar2__generic_int(int value)
  {
    return this.setVarB_Bar2__int_int(((int) value));
  }
  default public java.lang.Integer bar_Bar2__generic_int(java.lang.Integer a, int b)
  {
    return this.bar_Bar2__int_int(((int) a), ((int) b));
  }
}

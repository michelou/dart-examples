package generics;

public class Bar2__boolean_boolean extends dart._runtime.base.DartObject implements generics.Bar2_interface__boolean_boolean
{
    public boolean varA;
    public boolean varB;
  
    public Bar2__boolean_boolean(dart._runtime.helpers.ConstructorHelper.EmptyConstructorMarker arg, dart._runtime.types.simple.Type type)
    {
      super(arg, type);
    }
  
    public boolean bar_Bar2__boolean_boolean(boolean a, boolean b)
    {
      final dart._runtime.types.simple.TypeEnvironment dart2java$localTypeEnv = this.dart2java$type.env;
      return this.getVarA_Bar2__boolean_boolean();
    }
    public void _constructor()
    {
      final dart._runtime.types.simple.TypeEnvironment dart2java$localTypeEnv = this.dart2java$type.env;
      super._constructor();
    }
    public boolean getVarA_Bar2__boolean_boolean()
    {
      return this.varA;
    }
    public boolean getVarB_Bar2__boolean_boolean()
    {
      return this.varB;
    }
    public boolean setVarA_Bar2__boolean_boolean(boolean value)
    {
      this.varA = value;
      return value;
    }
    public boolean setVarB_Bar2__boolean_boolean(boolean value)
    {
      this.varB = value;
      return value;
    }
    public java.lang.Boolean getVarA()
    {
      return this.getVarA_Bar2__boolean_boolean();
    }
    public java.lang.Boolean getVarB()
    {
      return this.getVarB_Bar2__boolean_boolean();
    }
    public java.lang.Boolean setVarA(java.lang.Boolean value)
    {
      return this.setVarA_Bar2__boolean_boolean(((boolean) value));
    }
    public java.lang.Boolean setVarB(java.lang.Boolean value)
    {
      return this.setVarB_Bar2__boolean_boolean(((boolean) value));
    }
    public java.lang.Boolean bar(java.lang.Boolean a, java.lang.Boolean b)
    {
      return this.bar_Bar2__boolean_boolean(((boolean) a), ((boolean) b));
    }
}

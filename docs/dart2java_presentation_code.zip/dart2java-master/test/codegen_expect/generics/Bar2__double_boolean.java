package generics;

public class Bar2__double_boolean extends dart._runtime.base.DartObject implements generics.Bar2_interface__double_boolean
{
    public double varA;
    public boolean varB;
  
    public Bar2__double_boolean(dart._runtime.helpers.ConstructorHelper.EmptyConstructorMarker arg, dart._runtime.types.simple.Type type)
    {
      super(arg, type);
    }
  
    public double bar_Bar2__double_boolean(double a, boolean b)
    {
      final dart._runtime.types.simple.TypeEnvironment dart2java$localTypeEnv = this.dart2java$type.env;
      return this.getVarA_Bar2__double_boolean();
    }
    public void _constructor()
    {
      final dart._runtime.types.simple.TypeEnvironment dart2java$localTypeEnv = this.dart2java$type.env;
      super._constructor();
    }
    public double getVarA_Bar2__double_boolean()
    {
      return this.varA;
    }
    public boolean getVarB_Bar2__double_boolean()
    {
      return this.varB;
    }
    public double setVarA_Bar2__double_boolean(double value)
    {
      this.varA = value;
      return value;
    }
    public boolean setVarB_Bar2__double_boolean(boolean value)
    {
      this.varB = value;
      return value;
    }
    public java.lang.Double getVarA()
    {
      return this.getVarA_Bar2__double_boolean();
    }
    public java.lang.Boolean getVarB()
    {
      return this.getVarB_Bar2__double_boolean();
    }
    public java.lang.Double setVarA(java.lang.Double value)
    {
      return this.setVarA_Bar2__double_boolean(((double) value));
    }
    public java.lang.Boolean setVarB(java.lang.Boolean value)
    {
      return this.setVarB_Bar2__double_boolean(((boolean) value));
    }
    public java.lang.Double bar(java.lang.Double a, java.lang.Boolean b)
    {
      return this.bar_Bar2__double_boolean(((double) a), ((boolean) b));
    }
}

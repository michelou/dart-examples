package generics;

public interface Bar2_interface<A, B> extends dart._runtime.base.DartObject_interface
{
  A bar_Bar2(A a, B b);
  A getVarA_Bar2();
  B getVarB_Bar2();
  A setVarA_Bar2(A value);
  B setVarB_Bar2(B value);

}

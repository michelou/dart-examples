package generics;

public interface Bar2_interface__double_boolean extends dart._runtime.base.DartObject_interface, generics.Bar2_interface<java.lang.Double, java.lang.Boolean>, generics.Bar2_interface__double_generic<java.lang.Boolean>, generics.Bar2_interface__generic_boolean<java.lang.Double>
{
  double bar_Bar2__double_boolean(double a, boolean b);
  double getVarA_Bar2__double_boolean();
  boolean getVarB_Bar2__double_boolean();
  double setVarA_Bar2__double_boolean(double value);
  boolean setVarB_Bar2__double_boolean(boolean value);
  default public java.lang.Double getVarA_Bar2()
  {
    return this.getVarA_Bar2__double_boolean();
  }
  default public java.lang.Boolean getVarB_Bar2()
  {
    return this.getVarB_Bar2__double_boolean();
  }
  default public java.lang.Double setVarA_Bar2(java.lang.Double value)
  {
    return this.setVarA_Bar2__double_boolean(((double) value));
  }
  default public java.lang.Boolean setVarB_Bar2(java.lang.Boolean value)
  {
    return this.setVarB_Bar2__double_boolean(((boolean) value));
  }
  default public java.lang.Double bar_Bar2(java.lang.Double a, java.lang.Boolean b)
  {
    return this.bar_Bar2__double_boolean(((double) a), ((boolean) b));
  }
  default public double getVarA_Bar2__double_generic()
  {
    return this.getVarA_Bar2__double_boolean();
  }
  default public java.lang.Boolean getVarB_Bar2__double_generic()
  {
    return this.getVarB_Bar2__double_boolean();
  }
  default public double setVarA_Bar2__double_generic(double value)
  {
    return this.setVarA_Bar2__double_boolean(((double) value));
  }
  default public java.lang.Boolean setVarB_Bar2__double_generic(java.lang.Boolean value)
  {
    return this.setVarB_Bar2__double_boolean(((boolean) value));
  }
  default public double bar_Bar2__double_generic(double a, java.lang.Boolean b)
  {
    return this.bar_Bar2__double_boolean(((double) a), ((boolean) b));
  }
  default public java.lang.Double getVarA_Bar2__generic_boolean()
  {
    return this.getVarA_Bar2__double_boolean();
  }
  default public boolean getVarB_Bar2__generic_boolean()
  {
    return this.getVarB_Bar2__double_boolean();
  }
  default public java.lang.Double setVarA_Bar2__generic_boolean(java.lang.Double value)
  {
    return this.setVarA_Bar2__double_boolean(((double) value));
  }
  default public boolean setVarB_Bar2__generic_boolean(boolean value)
  {
    return this.setVarB_Bar2__double_boolean(((boolean) value));
  }
  default public java.lang.Double bar_Bar2__generic_boolean(java.lang.Double a, boolean b)
  {
    return this.bar_Bar2__double_boolean(((double) a), ((boolean) b));
  }
}

package generics;

public class Bar2__double_double extends dart._runtime.base.DartObject implements generics.Bar2_interface__double_double
{
    public double varA;
    public double varB;
  
    public Bar2__double_double(dart._runtime.helpers.ConstructorHelper.EmptyConstructorMarker arg, dart._runtime.types.simple.Type type)
    {
      super(arg, type);
    }
  
    public double bar_Bar2__double_double(double a, double b)
    {
      final dart._runtime.types.simple.TypeEnvironment dart2java$localTypeEnv = this.dart2java$type.env;
      return this.getVarA_Bar2__double_double();
    }
    public void _constructor()
    {
      final dart._runtime.types.simple.TypeEnvironment dart2java$localTypeEnv = this.dart2java$type.env;
      super._constructor();
    }
    public double getVarA_Bar2__double_double()
    {
      return this.varA;
    }
    public double getVarB_Bar2__double_double()
    {
      return this.varB;
    }
    public double setVarA_Bar2__double_double(double value)
    {
      this.varA = value;
      return value;
    }
    public double setVarB_Bar2__double_double(double value)
    {
      this.varB = value;
      return value;
    }
    public java.lang.Double getVarA()
    {
      return this.getVarA_Bar2__double_double();
    }
    public java.lang.Double getVarB()
    {
      return this.getVarB_Bar2__double_double();
    }
    public java.lang.Double setVarA(java.lang.Double value)
    {
      return this.setVarA_Bar2__double_double(((double) value));
    }
    public java.lang.Double setVarB(java.lang.Double value)
    {
      return this.setVarB_Bar2__double_double(((double) value));
    }
    public java.lang.Double bar(java.lang.Double a, java.lang.Double b)
    {
      return this.bar_Bar2__double_double(((double) a), ((double) b));
    }
}

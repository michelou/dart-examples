package generics;

public interface Qux3_interface<C, D, E> extends dart._runtime.base.DartObject_interface
{
  C qux_Qux3(C c, D d, E e);

}

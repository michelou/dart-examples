package generics;

public class Bar2__int_int extends dart._runtime.base.DartObject implements generics.Bar2_interface__int_int
{
    public int varA;
    public int varB;
  
    public Bar2__int_int(dart._runtime.helpers.ConstructorHelper.EmptyConstructorMarker arg, dart._runtime.types.simple.Type type)
    {
      super(arg, type);
    }
  
    public int bar_Bar2__int_int(int a, int b)
    {
      final dart._runtime.types.simple.TypeEnvironment dart2java$localTypeEnv = this.dart2java$type.env;
      return this.getVarA_Bar2__int_int();
    }
    public void _constructor()
    {
      final dart._runtime.types.simple.TypeEnvironment dart2java$localTypeEnv = this.dart2java$type.env;
      super._constructor();
    }
    public int getVarA_Bar2__int_int()
    {
      return this.varA;
    }
    public int getVarB_Bar2__int_int()
    {
      return this.varB;
    }
    public int setVarA_Bar2__int_int(int value)
    {
      this.varA = value;
      return value;
    }
    public int setVarB_Bar2__int_int(int value)
    {
      this.varB = value;
      return value;
    }
    public java.lang.Integer getVarA()
    {
      return this.getVarA_Bar2__int_int();
    }
    public java.lang.Integer getVarB()
    {
      return this.getVarB_Bar2__int_int();
    }
    public java.lang.Integer setVarA(java.lang.Integer value)
    {
      return this.setVarA_Bar2__int_int(((int) value));
    }
    public java.lang.Integer setVarB(java.lang.Integer value)
    {
      return this.setVarB_Bar2__int_int(((int) value));
    }
    public java.lang.Integer bar(java.lang.Integer a, java.lang.Integer b)
    {
      return this.bar_Bar2__int_int(((int) a), ((int) b));
    }
}

package generics;

public interface Bar2_interface__double_double extends dart._runtime.base.DartObject_interface, generics.Bar2_interface<java.lang.Double, java.lang.Double>, generics.Bar2_interface__double_generic<java.lang.Double>, generics.Bar2_interface__generic_double<java.lang.Double>
{
  double bar_Bar2__double_double(double a, double b);
  double getVarA_Bar2__double_double();
  double getVarB_Bar2__double_double();
  double setVarA_Bar2__double_double(double value);
  double setVarB_Bar2__double_double(double value);
  default public java.lang.Double getVarA_Bar2()
  {
    return this.getVarA_Bar2__double_double();
  }
  default public java.lang.Double getVarB_Bar2()
  {
    return this.getVarB_Bar2__double_double();
  }
  default public java.lang.Double setVarA_Bar2(java.lang.Double value)
  {
    return this.setVarA_Bar2__double_double(((double) value));
  }
  default public java.lang.Double setVarB_Bar2(java.lang.Double value)
  {
    return this.setVarB_Bar2__double_double(((double) value));
  }
  default public java.lang.Double bar_Bar2(java.lang.Double a, java.lang.Double b)
  {
    return this.bar_Bar2__double_double(((double) a), ((double) b));
  }
  default public double getVarA_Bar2__double_generic()
  {
    return this.getVarA_Bar2__double_double();
  }
  default public java.lang.Double getVarB_Bar2__double_generic()
  {
    return this.getVarB_Bar2__double_double();
  }
  default public double setVarA_Bar2__double_generic(double value)
  {
    return this.setVarA_Bar2__double_double(((double) value));
  }
  default public java.lang.Double setVarB_Bar2__double_generic(java.lang.Double value)
  {
    return this.setVarB_Bar2__double_double(((double) value));
  }
  default public double bar_Bar2__double_generic(double a, java.lang.Double b)
  {
    return this.bar_Bar2__double_double(((double) a), ((double) b));
  }
  default public java.lang.Double getVarA_Bar2__generic_double()
  {
    return this.getVarA_Bar2__double_double();
  }
  default public double getVarB_Bar2__generic_double()
  {
    return this.getVarB_Bar2__double_double();
  }
  default public java.lang.Double setVarA_Bar2__generic_double(java.lang.Double value)
  {
    return this.setVarA_Bar2__double_double(((double) value));
  }
  default public double setVarB_Bar2__generic_double(double value)
  {
    return this.setVarB_Bar2__double_double(((double) value));
  }
  default public java.lang.Double bar_Bar2__generic_double(java.lang.Double a, double b)
  {
    return this.bar_Bar2__double_double(((double) a), ((double) b));
  }
}

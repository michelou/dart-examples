package generics;

public interface Foo1_interface<T> extends dart._runtime.base.DartObject_interface
{
  void createInnerFoo_Foo1();
  T foo_Foo1(T t);
  void writeVariable_Foo1(T value);
  T getVariable_Foo1();
  generics.Foo1_interface<T> getAnotherFoo1_Foo1();
  T setVariable_Foo1(T value);
  generics.Foo1_interface<T> setAnotherFoo1_Foo1(generics.Foo1_interface<T> value);

}

package matrix;

public interface Matrix_interface extends matrix.BenchmarkBase_interface
{
  void run();

}

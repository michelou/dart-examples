package diamondsquare;

public interface DiamondSquare_interface extends diamondsquare.BenchmarkBase_interface
{
  void run();

}

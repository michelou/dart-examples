package diamondsquare;

public interface Expect_interface extends dart._runtime.base.DartObject_interface
{
  void fail(java.lang.String message);

}

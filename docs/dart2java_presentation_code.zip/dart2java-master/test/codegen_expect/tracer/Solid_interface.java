package tracer;

public interface Solid_interface extends tracer.Materials_interface
{
  tracer.Color_interface getColor_(java.lang.Number u, java.lang.Number v);
  tracer.Color_interface getColor();

}

package tracer;

public interface Background_interface extends dart._runtime.base.DartObject_interface
{
  tracer.Color_interface getColor();
  double getAmbience();

}

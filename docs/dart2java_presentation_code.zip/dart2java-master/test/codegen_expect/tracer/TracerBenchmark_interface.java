package tracer;

public interface TracerBenchmark_interface extends tracer.BenchmarkBase_interface
{
  void warmup();
  void exercise();

}

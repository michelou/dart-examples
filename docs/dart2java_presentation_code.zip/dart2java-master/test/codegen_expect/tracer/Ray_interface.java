package tracer;

public interface Ray_interface extends dart._runtime.base.DartObject_interface
{
  java.lang.String toString();
  java.lang.Object getPosition();
  java.lang.Object getDirection();

}

package tracer;

public interface Scene_interface extends dart._runtime.base.DartObject_interface
{
  java.lang.Object getCamera();
  java.lang.Object getShapes();
  java.lang.Object getLights();
  java.lang.Object getBackground();
  java.lang.Object setCamera(java.lang.Object value);
  java.lang.Object setShapes(java.lang.Object value);
  java.lang.Object setLights(java.lang.Object value);
  java.lang.Object setBackground(java.lang.Object value);

}

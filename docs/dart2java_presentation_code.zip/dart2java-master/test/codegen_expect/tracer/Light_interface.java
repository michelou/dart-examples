package tracer;

public interface Light_interface extends dart._runtime.base.DartObject_interface
{
  java.lang.Object getPosition();
  java.lang.Object getColor();
  java.lang.Object getIntensity();

}

package tracer;

public interface BaseShape_interface extends dart._runtime.base.DartObject_interface
{
  java.lang.String toString();
  java.lang.Object getPosition();
  java.lang.Object getMaterial();

}

package barnsleyfern;

public interface Fractal_interface extends barnsleyfern.BenchmarkBase_interface
{
  void run();
  int drawBarnsleyFern();

}

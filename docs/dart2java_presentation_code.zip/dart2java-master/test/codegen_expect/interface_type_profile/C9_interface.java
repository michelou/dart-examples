package interface_type_profile;

public interface C9_interface extends dart._runtime.base.DartObject_interface, interface_type_profile.B9_interface, interface_type_profile.B10_interface
{


}

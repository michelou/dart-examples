package interface_type_profile;

public interface A2_interface extends dart._runtime.base.DartObject_interface
{


}

package interface_type_profile;

public interface C2_interface extends dart._runtime.base.DartObject_interface, interface_type_profile.B2_interface, interface_type_profile.B3_interface
{


}

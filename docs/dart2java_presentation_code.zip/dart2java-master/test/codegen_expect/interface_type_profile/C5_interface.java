package interface_type_profile;

public interface C5_interface extends dart._runtime.base.DartObject_interface, interface_type_profile.B5_interface, interface_type_profile.B6_interface
{


}

package interface_type_profile;

public interface C13_interface extends dart._runtime.base.DartObject_interface, interface_type_profile.B13_interface, interface_type_profile.B14_interface
{


}

package interface_type_profile;

public class __TopLevel
{
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_A0 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.A0.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_A1 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.A1.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_A2 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.A2.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_A3 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.A3.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_List$ltObject$gt = new dart._runtime.types.simple.InterfaceTypeExpr(dart.core.List.dart2java$typeInfo, new dart._runtime.types.simple.TypeExpr[] {new dart._runtime.types.simple.InterfaceTypeExpr(dart._runtime.helpers.ObjectHelper.dart2java$typeInfo)});
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_B0 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.B0.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_B1 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.B1.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_B2 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.B2.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_B3 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.B3.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_B4 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.B4.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_B5 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.B5.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_B6 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.B6.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_B7 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.B7.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_B8 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.B8.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_B9 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.B9.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_B10 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.B10.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_B11 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.B11.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_B12 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.B12.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_B13 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.B13.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_B14 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.B14.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_B15 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.B15.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_C0 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.C0.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_C1 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.C1.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_C2 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.C2.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_C3 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.C3.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_C4 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.C4.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_C5 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.C5.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_C6 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.C6.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_C7 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.C7.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_C8 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.C8.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_C9 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.C9.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_C10 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.C10.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_C11 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.C11.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_C12 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.C12.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_C13 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.C13.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_C14 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.C14.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_C15 = new dart._runtime.types.simple.InterfaceTypeExpr(interface_type_profile.C15.dart2java$typeInfo);
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_Object = new dart._runtime.types.simple.InterfaceTypeExpr(dart._runtime.helpers.ObjectHelper.dart2java$typeInfo);
    static {
      final dart._runtime.types.simple.TypeEnvironment dart2java$localTypeEnv = dart._runtime.types.simple.TypeEnvironment.ROOT;
      interface_type_profile.__TopLevel.ITER_PARAM = 1;
      interface_type_profile.__TopLevel._rnd = dart.math.Random.factory$(1337);
      interface_type_profile.__TopLevel.level0 = ((dart.core.List_interface) dart._runtime.base.DartList.<java.lang.Object>specialfactory$fromArguments(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_List$ltObject$gt), interface_type_profile.A0._new_A0$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_A0)), interface_type_profile.A1._new_A1$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_A1)), interface_type_profile.A2._new_A2$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_A2)), interface_type_profile.A3._new_A3$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_A3))));
      interface_type_profile.__TopLevel.level1 = ((dart.core.List_interface) dart._runtime.base.DartList.<java.lang.Object>specialfactory$fromArguments(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_List$ltObject$gt), interface_type_profile.B0._new_B0$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_B0)), interface_type_profile.B1._new_B1$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_B1)), interface_type_profile.B2._new_B2$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_B2)), interface_type_profile.B3._new_B3$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_B3)), interface_type_profile.B4._new_B4$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_B4)), interface_type_profile.B5._new_B5$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_B5)), interface_type_profile.B6._new_B6$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_B6)), interface_type_profile.B7._new_B7$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_B7)), interface_type_profile.B8._new_B8$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_B8)), interface_type_profile.B9._new_B9$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_B9)), interface_type_profile.B10._new_B10$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_B10)), interface_type_profile.B11._new_B11$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_B11)), interface_type_profile.B12._new_B12$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_B12)), interface_type_profile.B13._new_B13$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_B13)), interface_type_profile.B14._new_B14$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_B14)), interface_type_profile.B15._new_B15$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_B15))));
      interface_type_profile.__TopLevel.level2 = ((dart.core.List_interface) dart._runtime.base.DartList.<java.lang.Object>specialfactory$fromArguments(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_List$ltObject$gt), interface_type_profile.C0._new_C0$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_C0)), interface_type_profile.C1._new_C1$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_C1)), interface_type_profile.C2._new_C2$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_C2)), interface_type_profile.C3._new_C3$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_C3)), interface_type_profile.C4._new_C4$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_C4)), interface_type_profile.C5._new_C5$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_C5)), interface_type_profile.C6._new_C6$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_C6)), interface_type_profile.C7._new_C7$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_C7)), interface_type_profile.C8._new_C8$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_C8)), interface_type_profile.C9._new_C9$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_C9)), interface_type_profile.C10._new_C10$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_C10)), interface_type_profile.C11._new_C11$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_C11)), interface_type_profile.C12._new_C12$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_C12)), interface_type_profile.C13._new_C13$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_C13)), interface_type_profile.C14._new_C14$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_C14)), interface_type_profile.C15._new_C15$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_C15))));
      interface_type_profile.__TopLevel.others = ((dart.core.List_interface) dart._runtime.base.DartList.<java.lang.Object>specialfactory$fromArguments(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_List$ltObject$gt), null, 3, 4.5, true, "string", dart._runtime.base.DartObject._new_Object$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_Object)), ((java.lang.Object) interface_type_profile.__TopLevel.level0)));
    }
    public static int ITER_PARAM;
    public static dart.math.Random_interface _rnd;
    public static dart.core.List_interface<java.lang.Object> level0;
    public static dart.core.List_interface<java.lang.Object> level1;
    public static dart.core.List_interface<java.lang.Object> level2;
    public static dart.core.List_interface<java.lang.Object> others;
  
  
  
    public static java.lang.Object randomFrom(dart.core.List_interface<java.lang.Object> l)
    {
      final dart._runtime.types.simple.TypeEnvironment dart2java$localTypeEnv = dart._runtime.types.simple.TypeEnvironment.ROOT;
      dart2java$localTypeEnv.evaluate(dart2java$typeExpr_List$ltObject$gt).check(l);
      return l.operatorAt_List(interface_type_profile.__TopLevel._rnd.nextInt(l.getLength_List()));
    }
    public static java.lang.Object randomObject()
    {
      final dart._runtime.types.simple.TypeEnvironment dart2java$localTypeEnv = dart._runtime.types.simple.TypeEnvironment.ROOT;
      int r = interface_type_profile.__TopLevel._rnd.nextInt(4);
      if ((r == 0))
      {
        return interface_type_profile.__TopLevel.randomFrom(((dart.core.List_interface) interface_type_profile.__TopLevel.level0));
      }
      if ((r == 1))
      {
        return interface_type_profile.__TopLevel.randomFrom(((dart.core.List_interface) interface_type_profile.__TopLevel.level1));
      }
      if ((r == 2))
      {
        return interface_type_profile.__TopLevel.randomFrom(((dart.core.List_interface) interface_type_profile.__TopLevel.level2));
      }
      return interface_type_profile.__TopLevel.randomFrom(((dart.core.List_interface) interface_type_profile.__TopLevel.others));
    }
    public static void main(String[] args)
    {
      final dart._runtime.types.simple.TypeEnvironment dart2java$localTypeEnv = dart._runtime.types.simple.TypeEnvironment.ROOT;
      int a0s = 0;
      int a1s = 0;
      int a2s = 0;
      int a3s = 0;
      int iters = ((1000 * 1000) * interface_type_profile.__TopLevel.ITER_PARAM);
      for (int i = 0; (i < iters); i = (i + 1))
      {
        java.lang.Object o = interface_type_profile.__TopLevel.randomObject();
        if (dart._runtime.helpers.TypeSystemHelper.getTrueType(o).isSubtypeOf(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_A0)))
        {
          a0s = (a0s + 1);
        }
        if (dart._runtime.helpers.TypeSystemHelper.getTrueType(o).isSubtypeOf(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_A1)))
        {
          a1s = (a1s + 1);
        }
        if (dart._runtime.helpers.TypeSystemHelper.getTrueType(o).isSubtypeOf(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_A2)))
        {
          a2s = (a2s + 1);
        }
        if (dart._runtime.helpers.TypeSystemHelper.getTrueType(o).isSubtypeOf(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_A3)))
        {
          a3s = (a3s + 1);
        }
      }
      dart.core.__TopLevel.print((((((("Percent of objects that are an A0: " + dart._runtime.helpers.DoubleHelper.operatorStar(dart._runtime.helpers.IntegerHelper.operatorDivide(a0s, iters), 100)) + " ") + "(expected ") + "") + ((((0.25 * 0.25) + (0.25 * 0.5)) + (0.25 * (16.0 / 16.0))) + dart._runtime.helpers.DoubleHelper.operatorStar(0.25, 0))) + ")"));
      dart.core.__TopLevel.print((((((("Percent of objects that are an A1: " + dart._runtime.helpers.DoubleHelper.operatorStar(dart._runtime.helpers.IntegerHelper.operatorDivide(a1s, iters), 100)) + " ") + "(expected ") + "") + ((((0.25 * 0.25) + (0.25 * 0.5)) + (0.25 * (12.0 / 16.0))) + dart._runtime.helpers.DoubleHelper.operatorStar(0.25, 0))) + ")"));
      dart.core.__TopLevel.print((((((("Percent of objects that are an A2: " + dart._runtime.helpers.DoubleHelper.operatorStar(dart._runtime.helpers.IntegerHelper.operatorDivide(a2s, iters), 100)) + " ") + "(expected ") + "") + ((((0.25 * 0.25) + (0.25 * 0.5)) + (0.25 * (10.0 / 16.0))) + dart._runtime.helpers.DoubleHelper.operatorStar(0.25, 0))) + ")"));
      dart.core.__TopLevel.print((((((("Percent of objects that are an A3: " + dart._runtime.helpers.DoubleHelper.operatorStar(dart._runtime.helpers.IntegerHelper.operatorDivide(a3s, iters), 100)) + " ") + "(expected ") + "") + ((((0.25 * 0.25) + (0.25 * 0.5)) + (0.25 * (9.0 / 16.0))) + dart._runtime.helpers.DoubleHelper.operatorStar(0.25, 0))) + ")"));
    }
}

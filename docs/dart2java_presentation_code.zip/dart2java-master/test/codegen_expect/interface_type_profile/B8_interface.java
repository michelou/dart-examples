package interface_type_profile;

public interface B8_interface extends dart._runtime.base.DartObject_interface, interface_type_profile.A3_interface
{


}

package interface_type_profile;

public interface C8_interface extends dart._runtime.base.DartObject_interface, interface_type_profile.B8_interface, interface_type_profile.B9_interface
{


}

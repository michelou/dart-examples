package interface_type_profile;

public interface C7_interface extends dart._runtime.base.DartObject_interface, interface_type_profile.B7_interface, interface_type_profile.B8_interface
{


}

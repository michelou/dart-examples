package interface_type_profile;

public interface C15_interface extends dart._runtime.base.DartObject_interface, interface_type_profile.B15_interface, interface_type_profile.B0_interface
{


}

package interface_type_profile;

public interface C14_interface extends dart._runtime.base.DartObject_interface, interface_type_profile.B14_interface, interface_type_profile.B15_interface
{


}

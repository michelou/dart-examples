package interface_type_profile;

public interface B6_interface extends dart._runtime.base.DartObject_interface, interface_type_profile.A2_interface, interface_type_profile.A1_interface
{


}

package interface_type_profile;

public interface A0_interface extends dart._runtime.base.DartObject_interface
{


}

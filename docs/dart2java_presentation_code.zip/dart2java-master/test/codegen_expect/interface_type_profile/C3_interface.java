package interface_type_profile;

public interface C3_interface extends dart._runtime.base.DartObject_interface, interface_type_profile.B3_interface, interface_type_profile.B4_interface
{


}

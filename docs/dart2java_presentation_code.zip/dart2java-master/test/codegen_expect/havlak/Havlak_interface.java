package havlak;

public interface Havlak_interface extends havlak.BenchmarkBase_interface
{
  void exercise();
  void warmup();
  havlak.CFG_interface getCfg();

}

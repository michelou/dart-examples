package addition;

public class __TopLevel
{
  
  
  
  
    public static void main(String[] args)
    {
      final dart._runtime.types.simple.TypeEnvironment dart2java$localTypeEnv = dart._runtime.types.simple.TypeEnvironment.ROOT;
      dart.core.__TopLevel.print((2 + 2));
      dart.core.__TopLevel.print((4 + dart._runtime.helpers.StringHelper.getLength("four")));
    }
}

package fluidmotion;

public interface FluidMotion_interface extends fluidmotion.BenchmarkBase_interface
{
  void warmup();
  void exercise();

}

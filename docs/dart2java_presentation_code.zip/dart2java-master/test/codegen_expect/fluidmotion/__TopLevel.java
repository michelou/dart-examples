package fluidmotion;

public class __TopLevel
{
    private static dart._runtime.types.simple.InterfaceTypeExpr dart2java$typeExpr_FluidMotion = new dart._runtime.types.simple.InterfaceTypeExpr(fluidmotion.FluidMotion.dart2java$typeInfo);
  
  
  
    public static void main(String[] args)
    {
      final dart._runtime.types.simple.TypeEnvironment dart2java$localTypeEnv = dart._runtime.types.simple.TypeEnvironment.ROOT;
      fluidmotion.FluidMotion._new_FluidMotion$(dart2java$localTypeEnv.evaluate(dart2java$typeExpr_FluidMotion)).report();
    }
}

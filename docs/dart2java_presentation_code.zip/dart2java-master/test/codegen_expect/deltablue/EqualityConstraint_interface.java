package deltablue;

public interface EqualityConstraint_interface extends deltablue.BinaryConstraint_interface
{
  void execute();

}

package deltablue;

public interface StayConstraint_interface extends deltablue.UnaryConstraint_interface
{
  void execute();

}

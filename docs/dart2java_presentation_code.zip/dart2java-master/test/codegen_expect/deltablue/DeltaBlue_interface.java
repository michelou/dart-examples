package deltablue;

public interface DeltaBlue_interface extends deltablue.BenchmarkBase_interface
{
  void run();

}

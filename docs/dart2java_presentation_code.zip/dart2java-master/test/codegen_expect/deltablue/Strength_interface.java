package deltablue;

public interface Strength_interface extends dart._runtime.base.DartObject_interface
{
  deltablue.Strength_interface nextWeaker();
  int getValue();
  java.lang.String getName();

}

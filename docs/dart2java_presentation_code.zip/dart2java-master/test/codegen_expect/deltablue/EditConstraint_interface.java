package deltablue;

public interface EditConstraint_interface extends deltablue.UnaryConstraint_interface
{
  boolean isInput();
  void execute();

}

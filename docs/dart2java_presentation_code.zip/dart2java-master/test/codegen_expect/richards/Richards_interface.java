package richards;

public interface Richards_interface extends richards.BenchmarkBase_interface
{
  void run();

}

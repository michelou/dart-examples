# Performance Benchmark of different Java invoke mechanisms

To run:

    ./java-invokes/build.sh
    ./analysis/run.sh

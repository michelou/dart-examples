#!/bin/bash
# Copyright 2016, the Dart project authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

set -e

# Switch to the root directory of dart2java.
cd $( dirname "${BASH_SOURCE[0]}" )/..

function fail {
  echo -e "[31mAnalyzer found problems[0m"
  return 1
}

echo "Running dartanalyzer to check for errors/warnings/hints..."
dartanalyzer --strong --fatal-warnings --package-warnings bin/dart2java.dart \
    | grep -v "\[info\] TODO" | (! grep $PWD) || fail
